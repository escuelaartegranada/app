import React, { useState, useEffect, useCallback } from 'react';
import GlassCard from './GlassCard';
import { getSavingTip } from '../services/geminiService';
import { LightbulbIcon } from './icons';

const SavingTips: React.FC = () => {
    const [tip, setTip] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(true);

    const fetchTip = useCallback(async () => {
        setLoading(true);
        const newTip = await getSavingTip();
        setTip(newTip);
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchTip();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <GlassCard className="flex flex-col justify-between">
            <div>
                <h2 className="text-xl font-bold mb-4 text-gray-100 flex items-center gap-2">
                    <LightbulbIcon />
                    Consejo de Ahorro
                </h2>
                <div className="min-h-[60px] flex items-center justify-center">
                    {loading ? (
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-500"></div>
                    ) : (
                        <p className="text-gray-300 italic text-center">"{tip}"</p>
                    )}
                </div>
            </div>
            <button
                onClick={fetchTip}
                disabled={loading}
                className="mt-4 w-full bg-slate-700 hover:bg-slate-600 text-gray-200 font-bold py-2 px-4 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
            >
                {loading ? 'Generando...' : 'Nuevo Consejo'}
            </button>
        </GlassCard>
    );
};

export default SavingTips;