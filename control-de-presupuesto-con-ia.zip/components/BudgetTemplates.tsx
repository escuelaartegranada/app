import React, { useState } from 'react';
import GlassCard from './GlassCard';
import { getBudgetTemplate } from '../services/geminiService';
import { TemplateIcon } from './icons';

const BudgetTemplates: React.FC = () => {
    const [description, setDescription] = useState<string>('');
    const [template, setTemplate] = useState<Record<string, number | string> | null>(null);
    const [loading, setLoading] = useState<boolean>(false);

    const handleGenerate = async () => {
        if (!description) return;
        setLoading(true);
        setTemplate(null);
        const templateString = await getBudgetTemplate(description);
        try {
            const parsedTemplate = JSON.parse(templateString);
            setTemplate(parsedTemplate);
        } catch (error) {
            console.error("Failed to parse template:", error);
            setTemplate({ error: "No se pudo interpretar la plantilla recibida." });
        }
        setLoading(false);
    };

    return (
        <GlassCard>
            <h2 className="text-xl font-bold mb-4 text-gray-100 flex items-center gap-2">
                <TemplateIcon />
                Plantillas de Presupuesto
            </h2>
            <p className="text-sm text-gray-400 mb-3">Describe tu situación (ej: "estudiante universitario", "familia con 2 hijos") para generar una plantilla.</p>
            <div className="flex gap-2 mb-4">
                <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe tu situación..."
                    className="flex-grow bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                />
                <button
                    onClick={handleGenerate}
                    disabled={loading || !description}
                    className="bg-gradient-to-r from-pink-500 to-yellow-500 hover:from-pink-600 hover:to-yellow-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                >
                    {loading ? '...' : 'Crear'}
                </button>
            </div>

            {loading && <div className="animate-pulse space-y-2 mt-4">
                <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                <div className="h-4 bg-slate-700 rounded w-1/2"></div>
                <div className="h-4 bg-slate-700 rounded w-2/3"></div>
            </div>}
            
            {template && !template.error && (
                <div className="mt-4 space-y-2">
                    <h3 className="font-semibold text-gray-200">Plantilla Sugerida:</h3>
                    <ul className="list-disc list-inside text-gray-300">
                        {Object.entries(template).map(([key, value]) => (
                            <li key={key}>
                                <span className="font-medium text-gray-200">{key}:</span> {value}%
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {template && template.error && (
                 <p className="mt-4 text-red-400 text-sm">{String(template.error)}</p>
            )}

        </GlassCard>
    );
};

export default BudgetTemplates;