import React, { useState } from 'react';
import GlassCard from './GlassCard';
import type { Category } from '../types';
import { PlusIcon } from './icons';

interface AddExpenseFormProps {
    categories: Category[];
    onAddExpense: (expense: { name: string; amount: number; category: string }) => void;
}

const AddExpenseForm: React.FC<AddExpenseFormProps> = ({ categories, onAddExpense }) => {
    const [name, setName] = useState('');
    const [amount, setAmount] = useState('');
    const [category, setCategory] = useState(categories[0]?.id || '');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !amount || !category) return;
        
        onAddExpense({
            name,
            amount: parseFloat(amount),
            category,
        });

        setName('');
        setAmount('');
        setCategory(categories[0]?.id || '');
    };

    return (
        <GlassCard>
            <h2 className="text-xl font-bold mb-4 text-gray-100">Añadir Gasto</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="expenseName" className="block text-sm font-medium text-gray-400 mb-1">Nombre</label>
                    <input
                        id="expenseName"
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Ej: Café con amigos"
                        className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                        required
                    />
                </div>
                <div>
                    <label htmlFor="expenseAmount" className="block text-sm font-medium text-gray-400 mb-1">Cantidad (€)</label>
                    <input
                        id="expenseAmount"
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="0.00"
                        className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                        required
                    />
                </div>
                <div>
                    <label htmlFor="expenseCategory" className="block text-sm font-medium text-gray-400 mb-1">Categoría</label>
                    <select
                        id="expenseCategory"
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition appearance-none"
                        style={{ background: 'url(\'data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%239ca3af%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22/%3E%3C/svg%3E\') no-repeat right 1rem center/10px 10px, rgb(30 41 59)' }}
                        required
                    >
                        {categories.map((cat) => (
                            <option key={cat.id} value={cat.id} className="bg-slate-900 text-gray-300">{cat.name}</option>
                        ))}
                    </select>
                </div>
                <button type="submit" className="w-full bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 text-white font-bold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-all duration-300 transform hover:scale-105">
                    <PlusIcon />
                    Añadir
                </button>
            </form>
        </GlassCard>
    );
};

export default AddExpenseForm;