import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, Sector } from 'recharts';
import GlassCard from './GlassCard';
import type { Expense } from '../types';
import { CATEGORIES } from '../constants';

interface ChartsProps {
    expenses: Expense[];
}

const COLORS = CATEGORIES.map(c => {
    switch(c.color) {
        case 'bg-blue-500': return '#3b82f6';
        case 'bg-green-500': return '#22c55e';
        case 'bg-yellow-500': return '#eab308';
        case 'bg-pink-500': return '#ec4899';
        case 'bg-red-500': return '#ef4444';
        case 'bg-purple-500': return '#a855f7';
        case 'bg-indigo-500': return '#6366f1';
        default: return '#6b7280';
    }
});

const renderActiveShape = (props: any) => {
  const RADIAN = Math.PI / 180;
  const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * sin;
  const mx = cx + (outerRadius + 30) * cos;
  const my = cy + (outerRadius + 30) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 22;
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';

  return (
    <g>
      <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill} className="font-bold">
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill="#e5e7eb">{`€${value.toFixed(2)}`}</text>
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} dy={18} textAnchor={textAnchor} fill="#9ca3af">
        {`( ${(percent * 100).toFixed(2)}%)`}
      </text>
    </g>
  );
};

const Charts: React.FC<ChartsProps> = ({ expenses }) => {
    const [view, setView] = useState<'weekly' | 'monthly'>('monthly');
    const [activeIndex, setActiveIndex] = useState(0);

    const onPieEnter = (_: any, index: number) => {
        setActiveIndex(index);
    };

    const weeklyData = useMemo(() => {
        const data = Array(7).fill(0).map((_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - i);
            return {
                name: d.toLocaleDateString('es-ES', { weekday: 'short' }),
                date: d,
                amount: 0,
            };
        }).reverse();

        expenses.forEach(expense => {
            const expenseDate = new Date(expense.date);
            const diffDays = Math.floor((new Date().getTime() - expenseDate.getTime()) / (1000 * 3600 * 24));
            if (diffDays < 7) {
                const dayIndex = 6 - diffDays;
                if (data[dayIndex]) {
                    data[dayIndex].amount += expense.amount;
                }
            }
        });
        return data;
    }, [expenses]);

    const monthlyData = useMemo(() => {
        const data: { [key: string]: number } = {};
        expenses.forEach(expense => {
            const categoryName = CATEGORIES.find(c => c.id === expense.category)?.name || 'Otros';
            if (data[categoryName]) {
                data[categoryName] += expense.amount;
            } else {
                data[categoryName] = expense.amount;
            }
        });
        return Object.entries(data).map(([name, value]) => ({ name, value }));
    }, [expenses]);
    
    const ActiveChart = () => {
        if (view === 'weekly') {
            return (
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={weeklyData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                        <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} tick={{ fill: '#9ca3af' }} />
                        <YAxis stroke="#9ca3af" fontSize={12} tick={{ fill: '#9ca3af' }} />
                        <Tooltip contentStyle={{ backgroundColor: 'rgba(31, 41, 55, 0.9)', border: '1px solid #4b5563', borderRadius: '0.5rem', color: '#e5e7eb' }} cursor={{ fill: 'rgba(100, 116, 139, 0.2)' }}/>
                        <Legend wrapperStyle={{ color: '#d1d5db', fontSize: '14px' }}/>
                        <Bar dataKey="amount" name="Gastos" fill="#4ade80" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            );
        }
        return (
             <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                    <Pie
                        activeIndex={activeIndex}
                        activeShape={renderActiveShape}
                        data={monthlyData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        onMouseEnter={onPieEnter}
                    >
                        {monthlyData.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                </PieChart>
            </ResponsiveContainer>
        );
    };

    return (
        <GlassCard>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-100">Análisis de Gastos</h2>
                <div className="flex bg-slate-800 p-1 rounded-lg">
                    <button onClick={() => setView('monthly')} className={`px-3 py-1 text-sm rounded-md transition-colors ${view === 'monthly' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white'}`}>Mensual</button>
                    <button onClick={() => setView('weekly')} className={`px-3 py-1 text-sm rounded-md transition-colors ${view === 'weekly' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white'}`}>Semanal</button>
                </div>
            </div>
            <ActiveChart />
        </GlassCard>
    );
};

export default Charts;