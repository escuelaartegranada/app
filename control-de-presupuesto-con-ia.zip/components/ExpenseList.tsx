import React from 'react';
import GlassCard from './GlassCard';
import type { Expense, Category } from '../types';
import { TrashIcon } from './icons';

interface ExpenseListProps {
    expenses: Expense[];
    onDeleteExpense: (id: number) => void;
    categories: Category[];
}

const ExpenseList: React.FC<ExpenseListProps> = ({ expenses, onDeleteExpense, categories }) => {
    const getCategoryInfo = (categoryId: string) => {
        return categories.find(c => c.id === categoryId) || { name: 'Desconocido', color: 'bg-gray-500', icon: () => null };
    };

    return (
        <GlassCard className="max-h-[450px] flex flex-col">
            <h2 className="text-xl font-bold mb-4 text-gray-100">Últimos Gastos</h2>
            <div className="overflow-y-auto pr-2 flex-grow">
                {expenses.length === 0 ? (
                    <p className="text-gray-400 text-center py-8">No hay gastos registrados.</p>
                ) : (
                    <ul className="space-y-3">
                        {expenses.map((expense) => {
                            const categoryInfo = getCategoryInfo(expense.category);
                            return (
                                <li key={expense.id} className="flex items-center justify-between bg-slate-800/50 hover:bg-slate-700/60 p-3 rounded-lg transition-all duration-200 hover:scale-[1.02]">
                                    <div className="flex items-center gap-3">
                                        <div className={`p-2 rounded-full ${categoryInfo.color}`}>
                                            {categoryInfo.icon({className: "w-5 h-5 text-white"})}
                                        </div>
                                        <div>
                                            <p className="font-semibold text-gray-200">{expense.name}</p>
                                            <p className="text-xs text-gray-400">{categoryInfo.name}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <p className="font-bold text-gray-200">€{expense.amount.toFixed(2)}</p>
                                        <button onClick={() => onDeleteExpense(expense.id)} className="text-red-400 hover:text-red-500 transition-colors duration-200 p-1 rounded-full hover:bg-black/20">
                                            <TrashIcon />
                                        </button>
                                    </div>
                                </li>
                            );
                        })}
                    </ul>
                )}
            </div>
        </GlassCard>
    );
};

export default ExpenseList;