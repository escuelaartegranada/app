import React from 'react';
import GlassCard from './GlassCard';

interface BudgetSummaryProps {
    total: number;
    spent: number;
    remaining: number;
}

const BudgetSummary: React.FC<BudgetSummaryProps> = ({ total, spent, remaining }) => {
    const percentageSpent = total > 0 ? (spent / total) * 100 : 0;
    const progressBarColor = percentageSpent > 90 ? 'bg-red-500' : percentageSpent > 70 ? 'bg-yellow-500' : 'bg-green-400';

    return (
        <GlassCard>
            <h2 className="text-xl font-bold mb-4 text-gray-100">Resumen Mensual</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div>
                    <p className="text-sm text-gray-400">Presupuesto</p>
                    <p className="text-2xl font-semibold text-white">€{total.toLocaleString('es-ES')}</p>
                </div>
                <div>
                    <p className="text-sm text-gray-400">Gastado</p>
                    <p className="text-2xl font-semibold text-red-400">€{spent.toLocaleString('es-ES')}</p>
                </div>
                <div>
                    <p className="text-sm text-gray-400">Disponible</p>
                    <p className="text-2xl font-semibold text-green-400">€{remaining.toLocaleString('es-ES')}</p>
                </div>
            </div>
            <div className="mt-6">
                <div className="bg-gray-700 rounded-full h-3">
                    <div
                        className={`h-3 rounded-full transition-all duration-500 ease-out ${progressBarColor}`}
                        style={{ width: `${Math.min(percentageSpent, 100)}%` }}
                    ></div>
                </div>
                <p className="text-right text-sm mt-1 text-gray-400">{percentageSpent.toFixed(1)}% Gastado</p>
            </div>
        </GlassCard>
    );
};

export default BudgetSummary;