
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getSavingTip = async (): Promise<string> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: "Dame un consejo de ahorro creativo y poco común, en español, en una sola frase.",
             config: { thinkingConfig: { thinkingBudget: 0 } }
        });
        return response.text;
    } catch (error) {
        console.error("Error fetching saving tip:", error);
        return "No se pudo obtener un consejo. Inténtalo de nuevo más tarde.";
    }
};

export const getBudgetTemplate = async (description: string): Promise<string> => {
    try {
        const prompt = `Genera una plantilla de presupuesto simple en formato JSON para una persona con esta descripción: "${description}". Incluye 5-7 categorías comunes con porcentajes sugeridos. El total de los porcentajes debe sumar 100. Responde únicamente con el objeto JSON, sin texto adicional ni markdown \`\`\`json. Ejemplo de formato: {"Vivienda": 35, "Comida": 15, ...}`;
        
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
            }
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
          jsonStr = match[2].trim();
        }
        
        // Basic validation before parsing
        if (jsonStr.startsWith("{") && jsonStr.endsWith("}")) {
            return jsonStr;
        } else {
            throw new Error("Respuesta de la IA no está en el formato JSON esperado.");
        }

    } catch (error) {
        console.error("Error fetching budget template:", error);
        return JSON.stringify({ error: "No se pudo generar la plantilla. Revisa la descripción e inténtalo de nuevo." });
    }
};
   